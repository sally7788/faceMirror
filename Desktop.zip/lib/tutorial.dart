import 'package:flutter/material.dart';

class TutorialScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('튜토리얼'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20),
                  Text(
                    '얼로가요?!',
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 20),
                  Text(
                    '본 어플리케이션은 안면마비환자의'
                        '\n재활치료를 돕기 위한 어플리케이션입니다',
                    style: TextStyle(fontSize: 20),
                  ),
                  SizedBox(height: 20),
                  Text(
                    '미소짓기, 찡그리기, 울상짓기, 놀라기 등'
                        '\n 다양한 표정 연습을 통하여'
                        '\n 안면근육 활성화 스트레칭을 해요',
                    style: TextStyle(fontSize: 20),
                  ),
                  SizedBox(height: 20),
                  Text(
                    '여러 표정을 활용해 방향 전환을 하고'
                        '\n 미로를 빠르게 통과해요!',
                    style: TextStyle(fontSize: 20),
                  ),
                ],
              ),
            ),
            Divider(height: 40, thickness: 2),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Column(
                    children: [
                      Text('웃으면 위로 올라가요'),
                      SizedBox(height: 10),
                      Image.asset('assets/images/smile.png', width: 80, height: 80),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Column(
                          children: [
                            Text(
                              '화나면 왼쪽으로 가요',
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 30),
                            Image.asset('assets/images/angry.png', width: 60, height: 50),
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          children: [
                            Text(
                              '슬프면 밑으로 가요',
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 30),
                            Image.asset('assets/images/sad.png', width: 60, height: 50),
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          children: [
                            Text(
                              '놀라면 오른쪽으로 가요',
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 30),
                            Image.asset('assets/images/surprise.png', width: 60, height: 50),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
