import 'package:flutter/material.dart';

class FinishScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final int time = ModalRoute.of(context)!.settings.arguments as int;

    String _formatTime(int seconds) {
      final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
      final secs = (seconds % 60).toString().padLeft(2, '0');
      return '$minutes:$secs';
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Game Clear'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '게임 클리어!',
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              '소요 시간: ${_formatTime(time)}',
              style: TextStyle(fontSize: 24),
            ),
          ],
        ),
      ),
    );
  }
}
