import 'package:flutter/material.dart';
import 'login.dart';
import 'menu1.dart';
import 'level.dart';
import 'high.dart';
import 'mid.dart';
import 'low.dart';
import 'highgame.dart';
import 'midgame.dart';
import 'lowgame.dart';
import 'finish.dart';
import 'tutorial.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/login': (context) => LoginScreen(),
        '/menu' :(context) => MenuScreen(),
        '/level' : (context) => LevelScreen(),
        '/high': (context) => HighScreen(),
        '/mid': (context) => MidScreen(),
        '/low': (context) => LowScreen(),
        '/highgame':(context)=>HighgameScreen(),
        '/midgame':(context)=>MidgameScreen(),
        '/lowgame':(context)=>LowgameScreen(),
        '/finish':(context)=>FinishScreen(),
        '/tutorial':(context)=>TutorialScreen(),

      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

      ),
      body: GestureDetector(
        onTap: () {
          Navigator.pushNamed(context, '/login');
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Align(
              alignment: Alignment(0, 1 / 3),
              child: Image.asset('assets/images/image.png'),
            ),
            SizedBox(height: 20), // 두 이미지 사이의 간격을 위한 SizedBox
            Image.asset('assets/images/type.png'),
          ],
        ),
      ),
    );
  }
}
