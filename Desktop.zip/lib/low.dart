import 'package:flutter/material.dart';

class LowScreen extends StatefulWidget {
  @override
  _LowScreenState createState() => _LowScreenState();
}

class _LowScreenState extends State<LowScreen> {
  int _countdown = 3;
  bool _showStartText = false;

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  void _startCountdown() async {
    for (int i = 3; i > 0; i--) {
      await Future.delayed(Duration(seconds: 1));
      setState(() {
        _countdown = i;
      });
    }
    await Future.delayed(Duration(seconds: 1));
    setState(() {
      _showStartText = true;
    });

    // START가 뜬 후 2초 뒤에 /Highgame으로 이동
    await Future.delayed(Duration(seconds: 1));
    Navigator.pushReplacementNamed(context, '/lowgame');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('High Level'),
      ),
      body: Stack(
        children: [
          Center(
            child: _showStartText
                ? Text(
              'START',
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            )
                : Text(
              '$_countdown',
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
