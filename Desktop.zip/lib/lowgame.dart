import 'package:flutter/foundation.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:typed_data';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

class LowgameScreen extends StatefulWidget {
  @override
  _LowgameScreenState createState() => _LowgameScreenState();
}

class _LowgameScreenState extends State<LowgameScreen> {
  CameraController? _cameraController;
  FaceDetector? _faceDetector;
  bool isProcessing = false;

  List<List<int>> maze = [
    [1, 0, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 1, 0, 1, 0, 1],
    [1, 1, 1, 0, 0, 1, 0, 1, 1, 1],
    [1, 0, 0, 0, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
  ];
  int playerX = 1, playerY = 0;
  Timer? _timer;
  int _seconds = 0;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _initializeFaceDetector();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _cameraController?.dispose();
    _faceDetector?.close();
    super.dispose();
  }

  void _initializeCamera() async {
    final cameras = await availableCameras();
    final frontCamera = cameras.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
    ); // 전면 카메라 선택

    _cameraController = CameraController(frontCamera, ResolutionPreset.medium);
    await _cameraController?.initialize();
    setState(() {});
    _cameraController?.startImageStream(_processCameraImage);
  }

  void _initializeFaceDetector() {
    final options = FaceDetectorOptions(
      enableClassification: true, // 얼굴 분류 활성화 (예: 웃음, 눈 뜸 여부)
    );
    _faceDetector = FaceDetector(options: options);
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _seconds++;
      });
    });
  }

  Future<void> _processCameraImage(CameraImage image) async {
    if (isProcessing) return;
    isProcessing = true;

    try {
      final InputImage inputImage = _getInputImageFromCameraImage(image);
      final List<Face> faces = await _faceDetector!.processImage(inputImage);

      if (faces.isNotEmpty) {
        final face = faces.first;
        _handleFaceExpression(face);
      }
    } catch (e) {
      print("Error processing camera image: $e");
    }

    isProcessing = false;
  }

  InputImage _getInputImageFromCameraImage(CameraImage image) {
    final WriteBuffer allBytes = WriteBuffer();
    for (final Plane plane in image.planes) {
      allBytes.putUint8List(plane.bytes);
    }
    final bytes = allBytes.done().buffer.asUint8List();

    final Size imageSize = Size(image.width.toDouble(), image.height.toDouble());

    final InputImageRotation rotation =
    _cameraController!.description.sensorOrientation == 90
        ? InputImageRotation.rotation270deg
        : InputImageRotation.rotation90deg;

    final inputImageMetadata = InputImageMetadata(
      size: imageSize,
      rotation: rotation,
      format: InputImageFormat.yuv420,
      bytesPerRow: image.planes.first.bytesPerRow,
    );

    return InputImage.fromBytes(bytes: bytes, metadata: inputImageMetadata);
  }

  void _handleFaceExpression(Face face) {
    final smilingProbability = face.smilingProbability ?? 0;
    final leftEyeOpenProbability = face.leftEyeOpenProbability ?? 0;
    final rightEyeOpenProbability = face.rightEyeOpenProbability ?? 0;

    if (smilingProbability > 0.7) {
      _movePlayer(0, -1); // 웃으면 위로 이동
    } else if (leftEyeOpenProbability < 0.3 && rightEyeOpenProbability > 0.7) {
      _movePlayer(-1, 0); // 화난 표정이면 왼쪽으로 이동
    } else if (leftEyeOpenProbability < 0.3 && rightEyeOpenProbability < 0.3) {
      _movePlayer(0, 1); // 슬픈 표정이면 아래로 이동
    } else if (smilingProbability < 0.1 && rightEyeOpenProbability > 0.7) {
      _movePlayer(1, 0); // 놀란 표정이면 오른쪽으로 이동
    }
  }

  void _movePlayer(int dx, int dy) {
    final newX = playerX + dx;
    final newY = playerY + dy;
    if (maze[newY][newX] == 0) {
      setState(() {
        playerX = newX;
        playerY = newY;
      });
      if (playerX == 8 && playerY == 9) {
        _timer?.cancel();
        Navigator.pushNamed(
          context,
          '/finish',
          arguments: _seconds,
        );
      }
    }
  }

  String _formatTime(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$secs';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Low Game'),
      ),
      body: Stack(
        children: [
          Positioned(
            right: 0,
            top: 0,
            width: 150,
            height: 150,
            child: _cameraController != null &&
                _cameraController!.value.isInitialized
                ? CameraPreview(_cameraController!)
                : Container(
              color: Colors.black,
              child: Center(child: CircularProgressIndicator()),
            ),
          ),
          Positioned(
            top: 20,
            left: 20,
            right: 20,
            child: Center(
              child: Text(
                'Time: ${_formatTime(_seconds)}',
                style: TextStyle(fontSize: 24),
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ...maze.asMap().entries.map((row) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: row.value.asMap().entries.map((cell) {
                      if (playerX == cell.key && playerY == row.key) {
                        return Container(
                          width: 30,
                          height: 30,
                          color: Colors.blue,
                        );
                      } else {
                        return Container(
                          width: 30,
                          height: 30,
                          color:
                          cell.value == 1 ? Colors.black : Colors.white,
                        );
                      }
                    }).toList(),
                  );
                }).toList(),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_upward),
                      onPressed: () => _movePlayer(0, -1),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back),
                      onPressed: () => _movePlayer(-1, 0),
                    ),
                    IconButton(
                      icon: Icon(Icons.arrow_downward),
                      onPressed: () => _movePlayer(0, 1),
                    ),
                    IconButton(
                      icon: Icon(Icons.arrow_forward),
                      onPressed: () => _movePlayer(1, 0),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
