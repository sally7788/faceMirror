import 'package:flutter/material.dart';

class LevelScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Level Screen'),
      ),
      body: SingleChildScrollView( // 스크롤 추가
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center, // X축 중앙 정렬
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50.0),
              child: Text(
                '레벨을 선택해주세요!',
                style: TextStyle(fontSize: 24),
              ),
            ),
            SizedBox(height: 20), // 텍스트와 이미지 사이의 여백
            Center(
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/high');
                },
                child: Image.asset('assets/images/high.png'), // high.png 버튼
              ),
            ),
            SizedBox(height: 20), // 이미지 사이의 여백
            Center(
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/mid');
                },
                child: Image.asset('assets/images/mid.png'), // mid.png 버튼
              ),
            ),
            SizedBox(height: 20), // 이미지 사이의 여백
            Center(
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/low');
                },
                child: Image.asset('assets/images/low.png'), // low.png 버튼
              ),
            ),
          ],
        ),
      ),
    );
  }
}
