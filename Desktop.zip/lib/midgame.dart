import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'dart:async';
class MidgameScreen extends StatefulWidget {
  @override
  _MidgameScreenState createState() => _MidgameScreenState();
}

class _MidgameScreenState extends State<MidgameScreen> {
  CameraController? _cameraController;
  List<List<int>> maze = [
    [1,1,1,0,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,1],
    [1,1,0,0,0,1,0,0,1,1],
    [1,0,0,1,1,1,0,0,0,1],
    [1,0,0,1,0,0,0,1,0,1],
    [1,1,1,1,0,0,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,1],
    [1,1,0,1,1,1,0,0,0,1],
    [1,0,0,1,0,0,0,0,0,1],
    [1,1,1,1,1,0,1,1,1,1],

  ];
  int playerX = 3, playerY = 0;
  Timer? _timer;
  int _seconds=0;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _cameraController?.dispose();
    super.dispose();
  }

  void _initializeCamera() async {
    final cameras = await availableCameras();
    _cameraController = CameraController(cameras[0], ResolutionPreset.medium);
    await _cameraController?.initialize();
    setState(() {});
  }

  void _startTimer(){
    _timer = Timer.periodic(Duration(seconds:1), (timer){
      setState((){
        _seconds++;
      });
    });
  }


  void _movePlayer(int dx, int dy) {
    final newX = playerX + dx;
    final newY = playerY + dy;
    if (maze[newY][newX] == 0) {
      setState(() {
        playerX = newX;
        playerY = newY;
      });
      if (playerX == 5 && playerY == 9) {
        _timer?.cancel();
        Navigator.pushNamed(context, '/finish',arguments:_seconds,);
      }
    }
  }

  String _formatTime(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$secs';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mid Game'),
      ),
      body: Stack(
        children: [
          Positioned(
            right: 0,
            top: 0,
            width: 150,
            height: 150,
            child: _cameraController != null && _cameraController!.value.isInitialized
                ? CameraPreview(_cameraController!)
                : Container(
              color: Colors.black,
              child: Center(child: CircularProgressIndicator()),
            ),
          ),
          Positioned(
            top:20,
            left:20,
            right:20,
            child:Center(
              child:Text(
                'Time: ${_formatTime(_seconds)}',
                style:TextStyle(fontSize:24),
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ...maze.asMap().entries.map((row) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: row.value.asMap().entries.map((cell) {
                      if (playerX == cell.key && playerY == row.key) {
                        return Container(
                          width: 30,
                          height: 30,
                          color: Colors.blue,
                        );
                      } else {
                        return Container(
                          width: 30,
                          height: 30,
                          color: cell.value == 1 ? Colors.black : Colors.white,
                        );
                      }
                    }).toList(),
                  );
                }).toList(),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_upward),
                      onPressed: () => _movePlayer(0, -1),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back),
                      onPressed: () => _movePlayer(-1, 0),
                    ),
                    IconButton(
                      icon: Icon(Icons.arrow_downward),
                      onPressed: () => _movePlayer(0, 1),
                    ),
                    IconButton(
                      icon: Icon(Icons.arrow_forward),
                      onPressed: () => _movePlayer(1, 0),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
